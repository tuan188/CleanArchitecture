//___FILEHEADER___

import SwiftUI
import CleanArchitecture

struct ___VARIABLE_productName___View: View {
    @ObservedObject var output: ___VARIABLE_productName___ViewModel.Output
    
    var cancelBag = CancelBag()
    
    var body: some View {
        Text("___VARIABLE_productName___")
    }
    
    init(viewModel: ___VARIABLE_productName___ViewModel) {
        let input = ___VARIABLE_productName___ViewModel.Input()
        self.output = viewModel.transform(input, cancelBag: cancelBag)
    }
}

struct ___VARIABLE_productName___View_Preview: PreviewProvider {
    static var previews: some View {
        Text("___VARIABLE_productName___")
    }
}
