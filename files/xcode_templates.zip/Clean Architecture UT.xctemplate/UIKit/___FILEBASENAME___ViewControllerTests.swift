//___FILEHEADER___

@testable import ___PROJECTNAME___
import XCTest
import UIKit

final class ___VARIABLE_productName___ViewControllerTests: XCTestCase {
    var viewController: ___VARIABLE_productName___ViewController!
    
    override func setUp() {
        super.setUp()
    }
}
