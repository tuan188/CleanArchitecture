//___FILEHEADER___

import SwiftUI
import Factory

protocol ShowMain {
    var window: UIWindow { get }
}

extension ShowMain {
    func showMain() {
        let view = Container.shared.mainView()
        let vc = UIHostingController(rootView: view)
        window.rootViewController = vc
        window.makeKeyAndVisible()
    }
}
