//___FILEHEADER___

@testable import ___PROJECTNAME___
import XCTest
import Combine
import CleanArchitecture

final class ___VARIABLE_productName___ViewModelTests: XCTestCase {
    private var viewModel: Test___VARIABLE_productName___ViewModel!
    private var input: ___VARIABLE_productName___ViewModel.Input!
    private var output: ___VARIABLE_productName___ViewModel.Output!
    private var cancelBag: CancelBag!

    // Triggers
    
    override func setUp() {
        super.setUp()
        viewModel = Test___VARIABLE_productName___ViewModel()
        input = ___VARIABLE_productName___ViewModel.Input()
        cancelBag = CancelBag()
        
        output = viewModel.transform(input, cancelBag: cancelBag)
    }
}

private final class Test___VARIABLE_productName___ViewModel: ___VARIABLE_productName___ViewModel {

}
