//___FILEHEADER___

import Combine
import Reusable
import Factory

final class ___VARIABLE_productName___ViewController: UIViewController, Bindable {
    
    // MARK: - IBOutlets
    
    // MARK: - Properties
    
    var viewModel: ___VARIABLE_productName___ViewModel!
    var disposeBag = DisposeBag()
    
    // MARK: - Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configView()
    }
    
    deinit {
        logDeinit()
    }
    
    // MARK: - Methods
    
    private func configView() {
        
    }
    
    func bindViewModel() {
        let input = ___VARIABLE_productName___ViewModel.Input()
        let output = viewModel.transform(input, disposeBag: disposeBag)
    }
}

// MARK: - Binders
extension ___VARIABLE_productName___ViewController {
    
}

// MARK: - StoryboardSceneBased
extension ___VARIABLE_productName___ViewController: StoryboardSceneBased {
    static var sceneStoryboard = UIStoryboard()
}

extension Container {
    // TODO: - update function name
    func viewController(navigationController: UINavigationController) -> Factory<___VARIABLE_productName___ViewController> {
        Factory(self) {
            let vc = ___VARIABLE_productName___ViewController.instantiate()
            let vm = ___VARIABLE_productName___ViewModel()
            vc.bindViewModel(to: vm)
            return vc
        }
    }
}
