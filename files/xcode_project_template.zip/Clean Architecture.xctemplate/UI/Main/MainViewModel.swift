//___FILEHEADER___

import Combine
import CleanArchitecture

class MainViewModel {
    
}

// MARK: - ViewModel
extension MainViewModel: ViewModel {
    struct Input {
        let loadTrigger: AnyPublisher<Void, Never>
    }
    
    final class Output: ObservableObject {
        
    }

    func transform(_ input: Input, cancelBag: CancelBag) -> Output {
        let output = Output()
        return output
    }
}
