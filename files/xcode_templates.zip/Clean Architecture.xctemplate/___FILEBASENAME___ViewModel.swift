//___FILEHEADER___

import Combine

final class ___VARIABLE_productName___ViewModel {

}

// MARK: - ViewModel
extension ___VARIABLE_productName___ViewModel: ViewModel {
    struct Input {
        
    }
    
    struct Output {
        
    }
    
    func transform(_ input: Input, disposeBag: DisposeBag) -> Output {
        let output = Output()
        return output
    }
}
