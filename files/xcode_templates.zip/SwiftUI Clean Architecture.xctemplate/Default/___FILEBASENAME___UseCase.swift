//___FILEHEADER___

import Combine

protocol ___VARIABLE_productName___UseCaseType {
    
}

struct ___VARIABLE_productName___UseCase: ___VARIABLE_productName___UseCaseType {
    
}
