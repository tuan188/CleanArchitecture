//___FILEHEADER___

import Combine
import SwiftUI
import CleanArchitecture

struct ___VARIABLE_productName___View: View {
    final class Triggers: ObservableObject {
        var load = PassthroughSubject<Void, Never>()
    }
    
    @StateObject var cancelBag: CancelBag
    @StateObject var viewModel: ___VARIABLE_productName___ViewModel
    @StateObject var output: ___VARIABLE_productName___ViewModel.Output
    @StateObject var triggers: Triggers
    
    var body: some View {
        Text("___VARIABLE_productName___")
    }
    
    init(viewModel: ___VARIABLE_productName___ViewModel) {
        let cancelBag = CancelBag()
        let triggers = Triggers()
        let input = ___VARIABLE_productName___ViewModel.Input(loadTrigger: triggers.load.eraseToAnyPublisher())
        let output = viewModel.transform(input, cancelBag: cancelBag)
        
        self._cancelBag = StateObject(wrappedValue: cancelBag)
        self._triggers = StateObject(wrappedValue: triggers)
        self._viewModel = StateObject(wrappedValue: viewModel)
        self._output = StateObject(wrappedValue: output)
    }
}

struct ___VARIABLE_productName___View_Preview: PreviewProvider {
    static var previews: some View {
        Text("___VARIABLE_productName___")
    }
}
