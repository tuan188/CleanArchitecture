//___FILEHEADER___

import UIKit
import Combine
import CleanArchitecture
import Factory

@UIApplicationMain
final class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
    var cancelBag = CancelBag()

    func applicationDidFinishLaunching(_ application: UIApplication) {
        let window = UIWindow(frame: UIScreen.main.bounds)
        self.window = window
        
        if NSClassFromString("XCTest") != nil { // test
            window.rootViewController = UnitTestViewController()
            window.makeKeyAndVisible()
        } else {
            bindViewModel(window: window)
        }
    }

    private func bindViewModel(window: UIWindow) {
        let vm = Container.shared.appViewModel(window: window)()
        
        vm.transform(
            AppViewModel.Input(load: Just(()).eraseToAnyPublisher()),
            cancelBag: cancelBag
        )
    }
}
