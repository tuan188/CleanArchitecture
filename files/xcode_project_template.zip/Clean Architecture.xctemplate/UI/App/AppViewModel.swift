//___FILEHEADER___

import CleanArchitecture
import Combine
import UIKit
import Factory

class AppViewModel: ShowMain {
    var window: UIWindow
    
    init(window: UIWindow) {
        self.window = window
    }
}

// MARK: - ViewModel
extension AppViewModel: ViewModel {
    struct Input {
        let load: AnyPublisher<Void, Never>
    }
    
    func transform(_ input: Input, cancelBag: CancelBag) {
        input.load
            .sink { [unowned self] in
                showMain()
            }
            .store(in: cancelBag)
    }
}

extension Container {
    func appViewModel(window: UIWindow) -> Factory<AppViewModel> {
        Factory(self) {
            AppViewModel(window: window)
        }
    }
}
