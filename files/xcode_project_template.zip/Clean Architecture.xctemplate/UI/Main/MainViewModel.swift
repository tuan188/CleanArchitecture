//___FILEHEADER___

import Combine
import CleanArchitecture

class MainViewModel {
    
}

// MARK: - ViewModel
extension MainViewModel: ViewModel {
    struct Input {
        
    }

    func transform(_ input: Input, cancelBag: CancelBag) {

    }
}
