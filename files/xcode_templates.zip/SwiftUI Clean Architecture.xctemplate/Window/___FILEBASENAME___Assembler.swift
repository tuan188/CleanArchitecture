//___FILEHEADER___

import UIKit

protocol ___VARIABLE_productName___Assembler {
    func resolve(window: UIWindow) -> ___VARIABLE_productName___View
    func resolve(window: UIWindow) -> ___VARIABLE_productName___ViewModel
    func resolve(window: UIWindow) -> ___VARIABLE_productName___NavigatorType
    func resolve() -> ___VARIABLE_productName___UseCaseType
}

extension ___VARIABLE_productName___Assembler {
    func resolve(window: UIWindow) -> ___VARIABLE_productName___View {
        return ___VARIABLE_productName___View(viewModel: resolve(window: window))
    }
    
    func resolve(window: UIWindow) -> ___VARIABLE_productName___ViewModel {
        return ___VARIABLE_productName___ViewModel(
            navigator: resolve(window: window),
            useCase: resolve()
        )
    }
}

extension ___VARIABLE_productName___Assembler where Self: DefaultAssembler {
    func resolve(window: UIWindow) -> ___VARIABLE_productName___NavigatorType {
        return ___VARIABLE_productName___Navigator(assembler: self, window: window)
    }
    
    func resolve() -> ___VARIABLE_productName___UseCaseType {
        return ___VARIABLE_productName___UseCase()
    }
}

extension ___VARIABLE_productName___Assembler where Self: PreviewAssembler {
    func resolve(window: UIWindow) -> ___VARIABLE_productName___NavigatorType {
        return ___VARIABLE_productName___Navigator(assembler: self, window: window)
    }
    
    func resolve() -> ___VARIABLE_productName___UseCaseType {
        return ___VARIABLE_productName___UseCase()
    }
}
