//___FILEHEADER___

import MGArchitecture
import RxSwift
import RxCocoa

struct ___VARIABLE_productName___ViewModel {
    let navigator: ___VARIABLE_productName___NavigatorType
    let useCase: ___VARIABLE_productName___UseCaseType
}

// MARK: - ViewModel
extension ___VARIABLE_productName___ViewModel: ViewModel {
    struct Input {
        
    }
    
    struct Output {
        
    }
    
    func transform(_ input: Input, disposeBag: DisposeBag) -> Output {
        let output = Output()
        return output
    }
}
