//___FILEHEADER___

import SwiftUI
import Combine
import CleanArchitecture
import Factory

struct MainView: View {
    @ObservedObject var viewModel: MainViewModel
    @ObservedObject var cancelBag = CancelBag()
    
    private let loadTrigger = PassthroughSubject<Void, Never>()
    
    var body: some View {
        Text("Hello, World!")
    }
    
    mutating func bindViewModel(viewModel: MainViewModel) {
        self.viewModel = viewModel
        let input = MainViewModel.Input()
        viewModel.transform(input, cancelBag: cancelBag)
    }
}

extension Container {
    var mainView: Factory<MainView> {
        Factory(self) {
            let vm = MainViewModel()
            var view = MainView(viewModel: vm)
            view.bindViewModel(viewModel: vm)
            return view
        }
    }
}
