//___FILEHEADER___

import Combine
import UIKit
import CleanArchitecture

// TODO: - Enter screen code
final class ___VARIABLE_productName___ViewController: UIViewController, Bindable {
    
    // MARK: - IBOutlets
    
    // MARK: - Properties
    
    var viewModel: ___VARIABLE_productName___ViewModel!
    var cancelBag = CancelBag()
    
    // MARK: - Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configView()
    }
    
    // MARK: - Methods
    
    private func configView() {
        
    }
    
    func bindViewModel() {
        let input = ___VARIABLE_productName___ViewModel.Input()
        let output = viewModel.transform(input, cancelBag: cancelBag)
    }
}
