//___FILEHEADER___

import SwiftUI
import Combine
import CleanArchitecture
import Factory

struct MainView: View {
    final class Triggers: ObservableObject {
        var load = PassthroughSubject<Void, Never>()
    }
    
    @StateObject var viewModel: MainViewModel
    @StateObject var output: MainViewModel.Output
    @StateObject var cancelBag: CancelBag
    @StateObject var triggers: Triggers
    
    var body: some View {
        Text("Main View")
    }
    
    init(viewModel: MainViewModel) {
        let triggers = Triggers()
        let cancelBag = CancelBag()
        
        let input = MainViewModel.Input(
            loadTrigger: triggers.load.eraseToAnyPublisher()
        )
        
        let output = viewModel.transform(input, cancelBag: cancelBag)
        
        self._viewModel = StateObject(wrappedValue: viewModel)
        self._output = StateObject(wrappedValue: output)
        self._cancelBag = StateObject(wrappedValue: cancelBag)
        self._triggers = StateObject(wrappedValue: triggers)
    }
}

extension Container {
    var mainView: Factory<MainView> {
        Factory(self) {
            let vm = MainViewModel()
            let view = MainView(viewModel: vm)
            return view
        }
    }
}
