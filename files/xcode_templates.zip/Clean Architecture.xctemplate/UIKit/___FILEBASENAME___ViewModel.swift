//___FILEHEADER___

import Combine
import CleanArchitecture

class ___VARIABLE_productName___ViewModel {

}

// MARK: - ViewModel
extension ___VARIABLE_productName___ViewModel: ViewModel {
    struct Input {
        
    }
    
    final class Output: ObservableObject {
        
    }
    
    func transform(_ input: Input, cancelBag: CancelBag) -> Output {
        let output = Output()
        return output
    }
}
