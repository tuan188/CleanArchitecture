//___FILEHEADER___

import SwiftUI

struct ___VARIABLE_productName___View: View {
    @ObservedObject var output: ___VARIABLE_productName___ViewModel.Output
    
    private let cancelBag = CancelBag()
    
    var body: some View {
        Text("___VARIABLE_productName___")
    }
    
    init(viewModel: ___VARIABLE_productName___ViewModel) {
        let input = ___VARIABLE_productName___ViewModel.Input()
        self.output = viewModel.transform(input, cancelBag: cancelBag)
    }
}

struct ___VARIABLE_productName___View_Preview: PreviewProvider {
    static var previews: some View {
        let viewModel: ___VARIABLE_productName___ViewModel = PreviewAssembler().resolve(
            window: UIWindow()
        )
        
        return ___VARIABLE_productName___View(viewModel: viewModel)
    }
}
