//___FILEHEADER___

@testable import ___PROJECTNAME___

final class ___VARIABLE_productName___UseCaseMock: ___VARIABLE_productName___UseCaseType {
    
}
